package com.cg.hotel.pl;


import java.util.ArrayList;
import java.util.Scanner;
import com.cg.hotel.dto.UserRegistration;
import com.cg.hotel.exception.UserRegistrationException;
import com.cg.hotel.service.UserRegistrationService;
import com.cg.hotel.service.UserRegistrationServiceImpl;

public class MainClass {
	static UserRegistrationService service = 
			new UserRegistrationServiceImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int choice = 0;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Registration");
				System.out.println("2-Remove Employee");
				System.out.println("3-Search By Id");
				System.out.println("4-Search All");
				System.out.println("5- update Employee");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				switch(choice)
				{
					case 1 : 
						
						UserRegistration	 ur = acceptUserRegistrationServiceDetails(); 
					if(ur!=null){	
					try
					{
						int id = service.addUserRegistration(ur);
						System.out.println("inserted and id = "+id);
					}
					catch(UserRegistrationException e)
					{
						System.out.println(e.getMessage());
					}}
					break;
					case 2: System.out.println("Enter to id to remove::");
					int id = sc.nextInt();
					try
					{
						UserRegistration ur1= service.removeUserRegistration(id);
						System.out.println("removed User "+ur1);
					}
					catch(UserRegistrationException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					
					case 3 : System.out.println("Enter id to search Employee::");
					int eid = sc.nextInt();
					try
					{
						UserRegistration ref = service.getUserRegistrationById(eid);
						System.out.println("emp "+ref);
					}
					catch(UserRegistrationException e)
					{
						System.out.println(e.getMessage());
					}
					break;
					
					case 4 : 
						try{ArrayList<UserRegistration>list = 
						service.getAllUserRegistration();
						for(UserRegistration obj : list)
						{
							System.out.println(obj);
						}
						}
						catch(UserRegistrationException e)
						{
							System.out.println(e.getMessage());
						}
						break;
					case 5: System.out.println("Enter id::");
					int id1= sc.nextInt();
					int phonenumber = sc.nextInt();
					try{
						UserRegistration eObj = service.updateUserRegistration(id1, phonenumber);
						System.out.println("updated = "+eObj);
					}
					catch(UserRegistrationException e)
					{
						System.out.println(e.getMessage());
					}
					break;
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
			}while(choice!=0);
		}

		
	}
	public static UserRegistration acceptUserRegistrationServiceDetails()
	{
		UserRegistration ur = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter fname::");
			String fname = sc.next();
			if(!service.validatefName(fname))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter lname::");
					String lname = sc.next();
					if(!service.validatelName(lname))
					{
						continue;
					}
					else
					{
						System.out.println("Enter phoneNumber::");
						int phnum=sc.nextInt();
						System.out.println("Enter MailId::");
						String mailid=sc.next();
						System.out.println("Enter address::");
						String addr=sc.next();
						
						
						
						if(fname!=null)
						{
							ur = new UserRegistration();
							ur.setFirstName(fname);
							ur.setLastName(lname);
							ur.setPhoneNumber(phnum);
							ur.setMailId(mailid);
							ur.setAddresss(addr);
							break;
						}
					}
				}
			}
			return ur;
		}
		
	}	
}
