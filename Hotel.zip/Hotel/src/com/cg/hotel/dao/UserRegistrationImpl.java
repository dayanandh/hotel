package com.cg.hotel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.logging.Logger;



import logger.Mylogger;

import com.cg.hotel.dto.UserRegistration;
import com.cg.hotel.exception.UserRegistrationException;
import com.cg.hotel.util.DBUtil;



public class UserRegistrationImpl implements UserRegistrationDao{
	Connection con;
	org.apache.log4j.Logger logger;
	
	
	public UserRegistrationImpl()
	{
		con = DBUtil.getConnect();
		logger = Mylogger.getLogger();
	}
	public int getUserRegistrationId()throws UserRegistrationException
	{
		logger.info("In getUserRegistrationId");
		int id = 0;
		String qry = "SELECT hId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got User With Id"+id);
			}
			}
			catch(SQLException e)
			{
				//logger.error("Error"+e.getMessage());
				throw new UserRegistrationException(e.getMessage());
			}
			logger.info("Completed getId");
			return id;
		
	}
	@Override
	public int addUserRegistration(UserRegistration ur)
			throws UserRegistrationException {
		int id = 0;
		String qry = "INSERT INTO HotelRegistration VALUES(hId_seq.NEXTVAL,?,?,?,?,?)";
		String fname = ur.getFirstName();
		String lname = ur.getLastName();
		int phonenumber=ur.getPhoneNumber();
		String mailid=ur.getMailId();
		String addr=ur.getAddresss();
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, fname);
			pstmt.setString(2, lname);
			pstmt.setInt(3,phonenumber);
			pstmt.setString(4,mailid);
			pstmt.setString(5, addr);
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getUserRegistrationId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new UserRegistrationException("unable to insert"+ur);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new UserRegistrationException(e.getMessage());
		}
		return id;
		
	}
	@Override
	public UserRegistration removeUserRegistration(int id)
			throws UserRegistrationException {
		UserRegistration	ur= null;
		String qry = "DELETE FROM HotelRegistration WHERE id=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ur = getUserRegistrationById(id);
			int row = pstmt.executeUpdate();
			if(ur==null)
			{
				throw new UserRegistrationException("User with id "+id+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted User with Id "+id);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new UserRegistrationException(e.getMessage());
		}
		return ur;
	}
	@Override
	public UserRegistration getUserRegistrationById(int id)
			throws UserRegistrationException {
		UserRegistration ur = null;
		String qry = "SELECT * FROM HotelRegistration WHERE id=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id1 = rs.getInt(1);
				String fname = rs.getString(2);
				String lname = rs.getString(3);
				int phonenumber=rs.getInt(4);
				String mailId = rs.getString(5);
				String address=rs.getString(6);
			
				ur = new UserRegistration(id1,fname,lname,phonenumber,mailId,address);
			}
			else
				throw new UserRegistrationException("User with id "+id+"not found");
		}
		catch(SQLException e)
		{
			throw new UserRegistrationException(e.getMessage());
		}
		return ur;
	
	}
	@Override
	public ArrayList<UserRegistration> getAllUserRegistration()
			throws UserRegistrationException {
		ArrayList<UserRegistration>list = new ArrayList<UserRegistration>();
		String qry = "SELECT * FROM HotelRegistration";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String fname = rs.getString(2);
				String lname = rs.getString(3);
				int phonenumber = rs.getInt(4);
				String mailid=rs.getString(5);
				String address=rs.getString(6);
				
				UserRegistration ur= new UserRegistration(id,fname,lname,phonenumber,mailid,address);
				list.add(ur);
			}
		}
		catch(SQLException e)
		{
			throw new UserRegistrationException(e.getMessage());
		}
		return list;
		
	}
	@Override
	public UserRegistration updateUserRegistration(int id, int phoneNumber)
			throws UserRegistrationException {
		UserRegistration ur = getUserRegistrationById(id);
		if(ur==null)
			throw new UserRegistrationException("Uer with id "+id+"Not found");
		else
		{
			String qry = "UPDATE HotelRegistration SET phonenumber=? WHERE id=?";
			try{
				PreparedStatement pstmt = 
						con.prepareStatement(qry);
				pstmt.setInt(1, ur.getPhoneNumber()+phoneNumber);
				pstmt.setInt(2, id);
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					System.out.println("updated successfully");
					ur = getUserRegistrationById(id);
				}      
			}
			catch(SQLException e)
			{
				throw new UserRegistrationException(e.getMessage());
			}
			
		}
		return ur;
	}
	
	
}
