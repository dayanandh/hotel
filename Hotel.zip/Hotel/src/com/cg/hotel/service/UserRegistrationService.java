package com.cg.hotel.service;

import java.util.ArrayList;

import com.cg.hotel.dto.UserRegistration;
import com.cg.hotel.exception.UserRegistrationException;

public interface UserRegistrationService {
	
int addUserRegistration(UserRegistration ur)throws UserRegistrationException;
	
	UserRegistration removeUserRegistration(int id)throws UserRegistrationException;
	
	UserRegistration getUserRegistrationById(int id)throws UserRegistrationException;
	
	ArrayList<UserRegistration>getAllUserRegistration()throws UserRegistrationException;
	
	UserRegistration updateUserRegistration(int id,int phoneNumber)throws UserRegistrationException;

	public boolean validatefName(String fname);
	
	public boolean validatelName(String lname);
}
