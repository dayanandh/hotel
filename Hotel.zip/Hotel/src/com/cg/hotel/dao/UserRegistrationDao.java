package com.cg.hotel.dao;

import java.util.ArrayList;

import com.cg.hotel.dto.UserRegistration;
import com.cg.hotel.exception.UserRegistrationException;



public interface UserRegistrationDao {
	
	
	int addUserRegistration(UserRegistration ur)throws UserRegistrationException;
	
	UserRegistration removeUserRegistration(int id)throws UserRegistrationException;
	
	UserRegistration getUserRegistrationById(int id)throws UserRegistrationException;
	
	ArrayList<UserRegistration>getAllUserRegistration()throws UserRegistrationException;
	
	UserRegistration updateUserRegistration(int id,int phoneNumber)throws UserRegistrationException;

}
