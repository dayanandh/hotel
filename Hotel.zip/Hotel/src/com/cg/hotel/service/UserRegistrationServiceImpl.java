package com.cg.hotel.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.hotel.dao.UserRegistrationDao;
import com.cg.hotel.dao.UserRegistrationImpl;
import com.cg.hotel.dto.UserRegistration;
import com.cg.hotel.exception.UserRegistrationException;


public class UserRegistrationServiceImpl implements UserRegistrationService{
UserRegistrationDao dao;
	
	public void setDao(UserRegistrationDao dao)
	{
		this.dao = dao;
	}
	
	public UserRegistrationServiceImpl()
	{
		dao = new UserRegistrationImpl();
	}

	@Override
	public int addUserRegistration(UserRegistration ur)
			throws UserRegistrationException {
		
		return dao.addUserRegistration(ur);
	}

	@Override
	public UserRegistration removeUserRegistration(int id)
			throws UserRegistrationException {
	
		return  dao.removeUserRegistration(id);
	}

	@Override
	public UserRegistration getUserRegistrationById(int id)
			throws UserRegistrationException {
		
		return dao.getUserRegistrationById(id);
	}

	@Override
	public ArrayList<UserRegistration> getAllUserRegistration()
			throws UserRegistrationException {
		
		return dao.getAllUserRegistration();
	}

	@Override
	public UserRegistration updateUserRegistration(int id, int phoneNumber)
			throws UserRegistrationException {
		
		return dao.updateUserRegistration(id, phoneNumber);
	}
	public boolean validatefName(String fname)
	{
		String pattern = "[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,fname))
		{
			return true;
		}
		else
			return false;
	}
	public boolean validatelName(String lname)
	{
		String pattern = "[A-Z]{1}[a-z]";
		if(Pattern.matches(pattern,lname))
		{
			return true;
		}
		else
			return false;
	}
	
}
