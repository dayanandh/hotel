package com.cg.hotel.dto;



public class UserRegistration {
	private int id;
	private String FirstName;
	private String LastName;
	private int phoneNumber;
	private String mailId;
	private String addresss;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		this.FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		this.LastName = lastName;
	}
	
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getAddresss() {
		return addresss;
	}
	public void setAddresss(String addresss) {
		this.addresss = addresss;
	}


	@Override
	public String toString() {
		return "UserRegistration [id=" + id + ", FirstName=" + FirstName
				+ ", LastName=" + LastName + ", phoneNumber=" + phoneNumber
				+ ", mailId=" + mailId + ", addresss=" + addresss + "]";
	}
	public UserRegistration(int id, String firstName, String lastName,
			int phoneNumber, String mailId, String addresss) {
		this.id = id;
		this.FirstName = firstName;
		this.LastName = lastName;
		this.phoneNumber = phoneNumber;
		this.mailId = mailId;
		this.addresss = addresss;
	}
	public UserRegistration() {
		// TODO Auto-generated constructor stub
	}
	
	

}
