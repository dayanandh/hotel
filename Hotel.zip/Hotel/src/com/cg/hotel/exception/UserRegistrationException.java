package com.cg.hotel.exception;

public class UserRegistrationException extends Exception {
 
	String message;
	
	public UserRegistrationException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}

}
